import * as dragulaExpt from 'dragula';
export const dragula: (containers?: any, options?: any) => any = (dragulaExpt as any).default || dragulaExpt;
